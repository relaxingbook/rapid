<?php
$upload_services[] = 'mediafree.co';
$max_file_size['mediafree.co'] = 2000;
$page_upload['mediafree.co'] = 'mediafree.co.php';
?>