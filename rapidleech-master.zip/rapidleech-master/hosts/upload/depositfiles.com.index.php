<?php
$upload_services[]="depositfiles.com";
$max_file_size["depositfiles.com"]=2048;
$page_upload["depositfiles.com"] = "depositfiles.com.php";
?>