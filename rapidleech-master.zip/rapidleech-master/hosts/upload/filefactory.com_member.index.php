<?php
$upload_services[] = 'filefactory.com_member';
$max_file_size['filefactory.com_member'] = 5120;
$page_upload['filefactory.com_member'] = 'filefactory.com_member.php';