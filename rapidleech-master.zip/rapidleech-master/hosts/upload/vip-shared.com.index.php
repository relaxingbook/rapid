<?php
$upload_services[]="vip-shared.com";
$max_file_size["vip-shared.com"]=2048;
$page_upload["vip-shared.com"] = "vip-shared.com.php";  
?>