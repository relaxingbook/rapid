<?php
$upload_services[]="wikifortio.com";
$max_file_size["wikifortio.com"]=100;
$page_upload["wikifortio.com"] = "wikifortio.com.php";  
?>