<?php
$upload_services[]="openload.co";
$max_file_size["openload.co"]=1024; //I don't know it
$page_upload["openload.co"] = "openload.co.php";  
?>