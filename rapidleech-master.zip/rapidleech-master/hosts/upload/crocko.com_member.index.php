<?php 

$upload_services[] = "crocko.com_member";

$max_file_size["crocko.com_member"] = 2048;

$page_upload["crocko.com_member"] = "crocko.com_member.php";

?>