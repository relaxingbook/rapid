<?php
$upload_services[]="mediafire.com_member";
$max_file_size["mediafire.com_member"]=200;
$page_upload["mediafire.com_member"] = "mediafire.com_member.php";

/******************mediafire.com****************************\
mediafire.com Member Upload Plugin
WRITTEN by Raj Malhotra on 06 Feb 2011
\******************mediafire.com****************************/
?>