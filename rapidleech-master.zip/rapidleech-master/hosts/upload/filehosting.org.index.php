<?php
$upload_services[] = 'filehosting.org';
$max_file_size['filehosting.org'] = false;
$page_upload['filehosting.org'] = 'filehosting.org.php';  
?>