<?php 
$upload_services[] = "netload.in_premium";
$max_file_size["netload.in_premium"] = 500;
$page_upload["netload.in_premium"] = "netload.in_premium.php";
?>