<?
$upload_services[]="bitshare.com_member";
$max_file_size["bitshare.com_member"]= 1000;
$page_upload["bitshare.com_member"] = "bitshare.com_member.php";
?>
